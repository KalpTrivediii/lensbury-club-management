<?php
//https://www.youtube.com/watch?v=qm4Eih_2p-M
   $Name=$_POST['name'];
   $Email=$_POST['email'];
   $Date=$_POST['date'];
   $Time=$_POST['time'];
   $Services=$_POST['services'];

   if(!empty($Name) || !empty($Email) ||!empty($Date) ||!empty($Time) ||!empty($Services))
   {
        $host="localhost";
        $user="root";
        $password="";
        $dbname="spa";
        $conn=new mysqli($host,$user,$password,$dbname);
        if(mysqli_connect_error())
        {
            die('connect error('.mysqli_connect_error(). ')' .mysqli_connect_error());
        }
        else
        {
            $select="SELECT email FROM spa_details WHERE email = ? LIMIT 1";
            $INSERT="INSERT INTO spa_details (name,email,date,time,services) values(?,?,?,?,?)";

            //prepare statement
            $stmt = $conn->prepare($select);
            $stmt->bind_param("s",$email);
            $stmt->execute();
            $stmt->bind_result($email);
            $stmt->store_result();
            $rnum=$stmt->num_rows;

            if($rnum==0)
            {
                $stmt->close();
                $stmt = $conn->prepare($INSERT);
                $stmt->bind_param("ssssii",$username, $email, $date, $time, $services);
                $stmt->execute();
                echo "New row inserted successfully";
            }
            else
            {
                echo "someone already have that email address!!";
            
            }
            $stml->close();
            $conn->close();
        }
   }
   else
   {
     echo "all fields required!!";
   }
   die();
?>